#include <fstream>
#include <string>
#include <iostream>
using namespace std;

int main() {
	ifstream f1("ret0.txt");
	ifstream f2("ret1.txt");
	ifstream f3("ret2.txt");
	ifstream f4("ret3.txt");
	ofstream fout("ret.txt");
	for (int i = 1; i <= 20; i++) {
		string s, s0;
		f4 >> s0;
		s += s0;
		f3 >> s0;
		s += s0;
		f2 >> s0;
		s += s0;
		f1 >> s0;
		s += s0;
		fout << s << endl;
	}
	return 0;
}
